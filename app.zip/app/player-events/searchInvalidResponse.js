module.exports = (client, message, query, tracks, content, collector) => {

    message.channel.send(`${client.emotes.error} -  **1** ve **${tracks.length} Arasında geçerli bir numara göndermelisiniz** !`);

};