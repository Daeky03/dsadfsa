module.exports = (client, message, track) => {

    message.channel.send(`${client.emotes.music} - Şarkı İsmi ***${track.title}*** Çaldığı Kanal ***${message.member.voice.channel.name}***...`);

};