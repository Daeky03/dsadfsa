module.exports = (client, message, queue) => {

    message.channel.send(`${client.emotes.error} -  ***Sesli Sohbetde Kimse Kalmadığı İçin Sesli Sohbetden Ayrıldım!***`);

};