module.exports = (client, message, playlist) => {

    message.channel.send(`${client.emotes.music} -**Şarkı ${playlist.title} Sıraya Eklendi (**${playlist.items.length}** ) !`);

};