module.exports = (client, message, queue) => {

    message.channel.send(`${client.emotes.error} - ***Kuyrukta daha fazla müzik olmadığı için müzik durdu ve Kanaldan Ayrıldım !***`);

};