# Zyra Müzik v2
Kurun Sizin Botunuz OLsun Çok Havalı Bir Müzik Sistemi Filtreler Bassboost, NightCore ve fazlası


- Discorda Gelin  [discord server](https://discord.gg/UdbQc9SdEY)

### Filtreler
bassboost, 8D, vaporwave, nightcore, phaser, tremolo, vibrato, reverse, treble, normalizer, surrounding, pulsator, subboost, karaoke, flanger, gate, haas, mcompand




```js
{
    "game": "Botda Gözükmesini İstediğiniz Durumu Yazın",
    "prefix": "PREFIX",
    "token_bot": "TOKEN"
} 
```

bir hata olursa konsola npm i yazın indirsin indirdikten sonrada hata verirse Daeky#1911 Ulaşın



```
#With Node
node index.js
```



