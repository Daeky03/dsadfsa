const emotes = require("../config/emojis.json");

exports.run = async (client, message, args) => {

    if (!message.member.voice.channel) return message.channel.send(`***Bir Sesli Kanala Bağlı Değilsin*** ${emotes.error}`);

    if (!args[0]) return message.channel.send(`***Başlaması İçin Şarkı İsmi Girmelisiniz*** ${emotes.error}`);

    client.player.play(message, args.join(" "));

};
