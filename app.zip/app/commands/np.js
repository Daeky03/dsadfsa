const emotes = require("../config/emojis.json");

exports.run = async (client, message) => {

    if (!message.member.voice.channel) return message.channel.send(`Bir Sesli Sohbete Bağlı Değilsin ${emotes.error}`);

    if (!client.player.getQueue(message)) return message.channel.send(`Şu Anda Çalan Şarkı Yok ${emotes.error}`);

    const track = await client.player.nowPlaying(message);

    message.channel.send({
        embed: {
            color: 'RED',
            author: { name: track.title },
            footer: { text: 'Nothing Lol' },
            fields: [
                { name: 'Kanal', value: track.author, inline: true },
                { name: 'Tarafından talep edildi', value: track.requestedBy.username, inline: true },
                { name: 'Çalma listesinden', value: track.fromPlaylist ? 'Yes' : 'No', inline: true },
                { name: 'Saniye(dk)', value: client.player.createProgressBar(message, { timecodes: true }), inline: true }
            ],
            thumbnail: { url: track.thumbnail },
            timestamp: new Date(),
        },
    });

};
