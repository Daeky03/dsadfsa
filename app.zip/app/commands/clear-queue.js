const emotes = require("../config/emojis.json");

exports.run = async (client, message) => {

    if (!message.member.voice.channel) return message.channel.send(`Bir Sesli Kanala Bağlı Değilsin ${emotes.error}`);

    if (!client.player.getQueue(message)) return message.channel.send(`Şu Anda Çalan Şarkı Yok ${emotes.error}`);

    client.player.clearQueue(message);

    message.channel.send(`Sıra Silindi ${emotes.success}`);

};
