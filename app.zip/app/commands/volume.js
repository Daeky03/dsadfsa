const emotes = require("../config/emojis.json");

exports.run = async (client, message, args) => {

    if (!message.member.voice.channel) return message.channel.send(`Bir Sesli Kanala Bağlı Değilsin ${emotes.error}`);

    if (!client.player.getQueue(message)) return message.channel.send(`Şu anda çalan şarkı yok ${emotes.error}`);

    if (!args[0]) return message.channel.send(`Lütfen Bir Sayı Girin ${emotes.error}`);

    if (isNaN(args[0]) || 250 < args[0] || args[0] <= 0) return message.channel.send(`Lütfen geçerli bir numara girin (1 ile 250 arasında) ${emotes.error}`);

    if (message.content.includes('-') || message.content.includes('+') || message.content.includes(',') || message.content.includes('.')) return message.channel.send(`Please enter a valid number ${emotes.error}`);

    client.player.setVolume(message, parseInt(args.join(" ")));

    message.channel.send(`Ses Ayarlandı Ses Yüzdesi **${args.join(" ")}%** ${emotes.success}`);

};
