const emotes = require("../config/emojis.json");

exports.run = async (client, message) => {

    if (!message.member.voice.channel) return message.channel.send(`Bir Sesli Kanala Bağlı Değilsin ${emotes.error}`);

    if (!client.player.getQueue(message)) return message.channel.send(`Şu Anda Çalan Şarkı Yok ${emotes.error}`);

    client.player.shuffle(message);

    return message.channel.send(`Şarkı Sırası Karıştırıldı **${client.player.getQueue(message).tracks.length}** Şarkı(lar) ${emotes.success}`);

};
