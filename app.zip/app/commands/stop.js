const emotes = require("../config/emojis.json");

exports.run = async (client, message) => {

    if (!message.member.voice.channel) return message.channel.send(`Bir Sesli Kanala Bağlı Değilsin ${emotes.error}`);

    if (!client.player.getQueue(message)) return message.channel.send(`Şu anda çalan şarkı yok ${emotes.error}`);

    client.player.setRepeatMode(message, false);
    client.player.stop(message);

    message.channel.send(`Şarkı **KAPATILDI** Sesli Sohbetten **Ayrıldım** ${emotes.success}`);

};
