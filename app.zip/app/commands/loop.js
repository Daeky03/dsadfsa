const emotes = require("../config/emojis.json");

exports.run = async (client, message) => {

    if (!message.member.voice.channel) return message.channel.send(`Bir Sesli Kanala Bağlı Değilsin ${emotes.error}`);

    if (!client.player.getQueue(message)) return message.channel.send(`Şu Anda Çalan Şarkı Yok ${emotes.error}`);

    const repeatMode = client.player.getQueue(message).repeatMode;

    if (repeatMode) {
        client.player.setRepeatMode(message, false);
        return message.channel.send(`Döngü Modu **Kapalı** ${emotes.success}`);
    } else {
        client.player.setRepeatMode(message, true);
        return message.channel.send(`Döngü Modu **Açık** ${emotes.success}`);
    };

};
